<?php
require 'PHPMailerAutoload.php';


	 class email{
		public $email;
		public function __construct(){
			$dsn = "mysql:host=localhost;dbname=gestion_des_notes";
			$user = "root";
			$passwd = "";
			$this->email = new PHPMailer;
			$this->email->isSMTP();                                      // Set mailer to use SMTP
			$this->email->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
			$this->email->SMTPAuth = true;                               // Enable SMTP authentication
			$this->email->Username = 'hanidayday@gmail.com';                 // SMTP username
			$this->email->Password = 'Aqzsedrf123';                           // SMTP password
			$this->email->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
			$this->email->Port = 587;   
			$this->email->SMTPOptions = array(
				'ssl' => array(
					'verify_peer' => false,
					'verify_peer_name' => false,
					'allow_self_signed' => true
				)
			);  
		}
		public function confirmation($email,$code,$nom){
				$this->email->setFrom('hanidayday@gmail.com', 'SUPPORT@SITE.COM');
				$this->email->addAddress($email, $nom);
				$this->email->isHTML(true);                                  // Set email format to HTML
				$this->email->Subject = "Confirmation Compte";
				$this->email->Body    = '<tr>
										<td class="wrapper">
										<table role="presentation" border="0" cellpadding="0" cellspacing="0">
										<tr>
										<td>
										<p>Bonjour,</p>
										<p>Votre code est :<b> '.$code.' </b>. Veuillez entrez dans le champs dans notre page</p>
										<p>Good luck! Hope it works.</p>
										</td>
										</tr>
										</table>
										</td>
										</tr>';
				if(!$this->email->send()) {
					return true;
				}else{
					return false;
				}
		}

	}
